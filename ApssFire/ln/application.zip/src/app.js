//window.Mustache = Mustache;
$(document).ready(function(){

    var lineMain = LineMain.getInstance();

});